
#include <stdio.h>                  // 标准输入输出库，用于打印输出
#include <string.h>                 // 字符串操作库，用于字符串处理
#include <stdlib.h>                 // 标准库函数
#include <unistd.h>                 // UNIX标准库，用于睡眠功能
#include <math.h>                   // 数学库


#include "ohos_init.h"              // HarmonyOS初始化头文件
#include "cmsis_os2.h"              // CMSIS-RTOS v2头文件
#include "wifiiot_errno.h"          // WiFi IoT错误代码头文件
#include "wifiiot_gpio.h"           // WiFi IoT GPIO头文件
#include "wifiiot_gpio_ex.h"        // WiFi IoT GPIO扩展头文件
#include "wifiiot_adc.h"            // WiFi IoT ADC头文件
#include "wifiiot_uart.h"           // WiFi IoT UART头文件
#include "wifiiot_pwm.h"


#define MAIN_TASK_STACK_SIZE 1024 * 10   // 定义UART任务栈大小为8KB
#define MAIN_TASK_PRIO 25                // 定义UART任务优先级为25
#define UART_BUFF_SIZE 1000              // 定义UART缓冲区大小为1000字节

//设置三种不同力度的PWM值
#define PWMFIRST   15000                 
#define PWMSECOND  18000
#define PWMTHIRD   22000


uint16_t data[3][100];
uint16_t i,j,k;
static const char *datacase = "9999\r\n";       //0x39

void Init_PWM(void);
int GetADC(WifiIotAdcChannelIndex channel);
void First_Init(void);
void ADC_Read_Data(uint16_t Idata);
static void Hello_World(void);

/***************************************************************
* 函数名称: Init_PWM
* 说    明: 写命令初始化三个PWM
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void Init_PWM(void)
{   
    
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_10, WIFI_IOT_IO_FUNC_GPIO_10_PWM1_OUT); //设置GPIO_10引脚复用功能为PWM
    GpioSetDir(WIFI_IOT_IO_NAME_GPIO_10, WIFI_IOT_GPIO_DIR_OUT);           //设置GPIO_10引脚为输出模式
    PwmInit(WIFI_IOT_PWM_PORT_PWM1);                                      //初始化PWM1端口
   
    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_11, WIFI_IOT_IO_FUNC_GPIO_11_PWM2_OUT); //设置GPIO_11引脚复用功能为PWM
    GpioSetDir(WIFI_IOT_IO_NAME_GPIO_11, WIFI_IOT_GPIO_DIR_OUT);           //设置GPIO_11引脚为输出模式
    PwmInit(WIFI_IOT_PWM_PORT_PWM2);                                      //初始化PWM2端口
   

    IoSetFunc(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_IO_FUNC_GPIO_12_PWM3_OUT); //设置GPIO_12引脚复用功能为PWM
    GpioSetDir(WIFI_IOT_IO_NAME_GPIO_12, WIFI_IOT_GPIO_DIR_OUT);           //设置GPIO_12引脚为输出模式
    PwmInit(WIFI_IOT_PWM_PORT_PWM3);                                      //初始化PWM3端口

    PwmStart(WIFI_IOT_PWM_PORT_PWM1, 0, 40000); 
    PwmStart(WIFI_IOT_PWM_PORT_PWM2, 0, 40000); 
    PwmStart(WIFI_IOT_PWM_PORT_PWM3, 0, 40000);

}



int GetADC(WifiIotAdcChannelIndex channel)
{
    unsigned int ret; // 定义变量用于存储ADC读取结果
    unsigned short datax; // 定义变量用于存储ADC读取的原始数据

    // 读取ADC值
    ret = AdcRead(channel, &datax, WIFI_IOT_ADC_EQU_MODEL_8,WIFI_IOT_ADC_CUR_BAIS_3P3V, 0xff);
    // 从ADC通道5读取数据，使用8次平均模型，默认电流偏置，等待时间为最大值

    if (ret != WIFI_IOT_SUCCESS) // 检查ADC读取是否成功
    {
        printf("ADC Read Fail\n"); // 读取失败时打印错误信息
    }

    // 返回读取到的adc值
    return (int)datax ;
   
}



/***************************************************************
* 函数名称: First_Init
* 说    明: 初始化GPIO和PWM
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void First_Init(void)
{
    GpioInit();  // 初始化GPIO
    Init_PWM();  // 初始化PWM

}





/***************************************************************
* 函数名称: ADC_Read_Data
* 说    明: 数据读取
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void ADC_Read_Data(uint16_t Idata)
{
    int ret;

    ret = GetADC(WIFI_IOT_ADC_CHANNEL_3);
    data[0][Idata] = ret;
    printf("%04d ",ret);

    ret = GetADC(WIFI_IOT_ADC_CHANNEL_4);
    data[1][Idata] = ret;
    printf("%04d ",ret);

    ret = GetADC(WIFI_IOT_ADC_CHANNEL_6);
    data[2][Idata] = ret;
    printf("%04d\n",ret);
    
    usleep(1500); // 延时
}




// 主任务函数
static void MAIN_Task(void)
{
    uint8_t uart_buff[UART_BUFF_SIZE] = {0};    // 定义并初始化UART缓冲区
    uint8_t *uart_buff_ptr = uart_buff;         // 定义UART缓冲区指针
    uint32_t ret;                               // 定义返回值变量


    WifiIotUartAttribute uart_attr = {
        // 设置UART波特率为9600
        .baudRate = 9600,
        // 设置数据位为8位
        .dataBits = 8,
        // 设置停止位为1位
        .stopBits = 1,
        // 设置无校验位
        .parity = 0,
    };

    First_Init();

    // 初始化UART驱动
    ret = UartInit(WIFI_IOT_UART_IDX_1, &uart_attr, NULL);
    if (ret != WIFI_IOT_SUCCESS) // 检查UART初始化是否成功
    {
        printf("Failed to init uart! Err code = %d\n", ret); // 输出错误信息
        return; // 结束函数
    }
    printf("UART Test Start\n"); // 输出测试开始信息
    
    
    
    while (1) // 无限循环
    {

        while(1)                                                    //接收运行命令
        {
            UartRead(WIFI_IOT_UART_IDX_1, uart_buff_ptr, UART_BUFF_SIZE);

            if(strcmp((char*)uart_buff_ptr, "01") == 0)
                break;
                
        }

        printf("Uart1 read data:%s\n", uart_buff_ptr); // 输出接收到的数据


      

        //第一力道读取数据,设置PWM数值
        PwmStart(WIFI_IOT_PWM_PORT_PWM1, PWMFIRST, 40000); 
        PwmStart(WIFI_IOT_PWM_PORT_PWM2, PWMFIRST, 40000); 
        PwmStart(WIFI_IOT_PWM_PORT_PWM3, PWMFIRST, 40000);


        for(i=0;i<100;i++)
            ADC_Read_Data(i);

        // 通过串口1发送数据
        for(i=0;i<300;i++)
            UartWrite(WIFI_IOT_UART_IDX_1, (unsigned char *)(data+i), 6);

        //第二力道读取数据,设置PWM数值
        PwmStart(WIFI_IOT_PWM_PORT_PWM1, PWMSECOND, 40000); 
        PwmStart(WIFI_IOT_PWM_PORT_PWM2, PWMSECOND, 40000); 
        PwmStart(WIFI_IOT_PWM_PORT_PWM3, PWMSECOND, 40000);


        for(i=0;i<100;i++)
            ADC_Read_Data(i);

        // 通过串口1发送数据
        for(i=0;i<300;i++)
            UartWrite(WIFI_IOT_UART_IDX_1, (unsigned char *)(data+i), 6);


        //第三力道读取数据,设置PWM数值
        PwmStart(WIFI_IOT_PWM_PORT_PWM1, PWMTHIRD, 40000); 
        PwmStart(WIFI_IOT_PWM_PORT_PWM2, PWMTHIRD, 40000); 
        PwmStart(WIFI_IOT_PWM_PORT_PWM3, PWMTHIRD, 40000);


        for(i=0;i<100;i++)
            ADC_Read_Data(i);

        // 通过串口1发送数据
        for(i=0;i<300;i++)
            UartWrite(WIFI_IOT_UART_IDX_1, (unsigned char *)(data+i), 6);

        PwmStart(WIFI_IOT_PWM_PORT_PWM1, 0, 40000); 
        PwmStart(WIFI_IOT_PWM_PORT_PWM2, 0, 40000); 
        PwmStart(WIFI_IOT_PWM_PORT_PWM3, 0, 40000);

        
    }
}


static void Hello_World(void)
{
    osThreadAttr_t attr; // 定义线程属性结构体

    // 设置线程属性
    attr.name = "MAIN_Task"; // 设置线程名称
    attr.attr_bits = 0U;     // 设置线程属性位
    attr.cb_mem = NULL;      // 设置线程控制块内存指针
    attr.cb_size = 0U;       // 设置线程控制块大小
    attr.stack_mem = NULL;   // 设置线程栈内存指针
    attr.stack_size = MAIN_TASK_STACK_SIZE; // 设置线程栈大小
    attr.priority = MAIN_TASK_PRIO;         // 设置线程优先级

    // 创建UART任务线程
    if (osThreadNew((osThreadFunc_t)MAIN_Task, NULL, &attr) == NULL)
    {
        printf("Falied to create MAIN_Task!\n"); // 输出错误信息
    }
}



APP_FEATURE_INIT(Hello_World); // 注册Hello_World函数为应用初始化函数
