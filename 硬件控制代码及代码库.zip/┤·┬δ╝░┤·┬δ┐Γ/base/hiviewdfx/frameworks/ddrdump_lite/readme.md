详见：https://gitee.com/openharmony/docs/blob/master/readme/DFX子系统README.md
