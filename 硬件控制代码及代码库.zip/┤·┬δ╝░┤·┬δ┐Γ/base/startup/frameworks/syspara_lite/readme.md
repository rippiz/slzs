详见：https://gitee.com/openharmony/docs/blob/master/readme/启动恢复README.md
