详见：https://gitee.com/openharmony/docs/blob/master/readme/公共基础README.md
