详见：https://gitee.com/openharmony/docs/blob/master/readme/全球化子系统README.md
